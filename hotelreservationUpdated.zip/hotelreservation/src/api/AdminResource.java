package api;

import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.Room;

import java.util.*;

/**
 * @author Umesh Gholap
 *
 */
public class AdminResource {

    private static final AdminResource SINGLETON = new AdminResource();

    private final CustomerService customerService = CustomerService.getSingleton();
    private final ReservationService reservationService = ReservationService.getSingleton();

    private final HashMap<String, Customer> customers = new HashMap<>();

    private AdminResource() {
    }

    public static AdminResource getSingleton() {
        return SINGLETON;
    }


    public void addCustomer( String email, String firstName, String lastName) {
        customers.put(email, new Customer(firstName, lastName, email));
    }



    public HashMap<String,Customer> getAllCustomers() {
        return customers;
    }

    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    public void addRoom(Room room)
    {

        reservationService.addRoom(room);
    }



    public void displayAllReservations() {
        reservationService.displayAllReservation();
    }



}