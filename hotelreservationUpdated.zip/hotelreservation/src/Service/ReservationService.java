package Service;


import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * @author Umesh Gholap
 *
 */
public class ReservationService {

    private static final ReservationService SINGLETON = new ReservationService();
    private static final int ROOMS_DEFAULT_DAYS = 7;

    public static HashMap<String, IRoom> rooms = new HashMap<>();
    HashMap<String, LinkedList<Reservation>> reservations = new HashMap<>();
    private ReservationService() {
    }

    public static ReservationService getSingleton() {
        return SINGLETON;
    }

    public void addRoom(IRoom room) {
        rooms.put(room.getRoomNumber(), room);
    }
    public IRoom getARoom(String roomNumber) {
        return rooms.get(roomNumber);
    }

    public Collection<IRoom> getAllRooms() {
        return rooms.values();
    }

    public Reservation reserveRoom(Customer customer, String room,
                                   Date checkInDate, Date checkOutDate) {

        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        LinkedList<Reservation> customerRes = getCustomersReservation(customer);

        if (customerRes == null) {
            customerRes = new LinkedList<>();
        }

        customerRes.add(reservation);
        reservations.put(customer.getEmail(), customerRes);

        return reservation;
    }
    public LinkedList<Reservation> getCustomersReservation(Customer customer) {
        return reservations.get(customer.getEmail());
    }

    public void displayAllReservation() {
        final LinkedList<Reservation> res = getAllReservations();

        if (res.isEmpty()) {
            System.out.println("Reservations not found");
        } else {
            for (Reservation reservationVal : res) {
                System.out.println(reservationVal + "\n");
            }
        }
    }

    private LinkedList<Reservation> getAllReservations() {
        LinkedList<Reservation> Reservations = new LinkedList<>();

        for(LinkedList<Reservation> resVal : reservations.values()) {
            Reservations.addAll(resVal);
        }

        return Reservations;
    }




}