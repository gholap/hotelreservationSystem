package model;

import api.HotelResource;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static Service.CustomerService.customers;

/**
 * @author Umesh Gholap
 *
 */
public class MainMenu {

    private static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
    private static final HotelResource hotelResource = HotelResource.getSingleton();

    public static void main(String args[]) throws ParseException {

        displayMainMenu();
            String option = "";
            Scanner scanner = new Scanner(System.in);
            
                do {
                    option = scanner.nextLine();

                    if (option.length() == 1)
                    {
                        switch (option.charAt(0))
                        {
                            case '1':
                                findAndReserveRoom();
                                break;
                            case '2':
                                seeMyReservation();
                                break;
                            case '3':
                                createCustomerAccount();
                                break;
                            case '4':
                                AdminMenu.adminMenu();
                                break;
                            case '5':
                                System.out.println("Exit");
                                break;
                            default:
                                System.out.println("Undefined action action\n");
                                break;
                        }
                    }
                } while (option.charAt(0) != '5' || option.length() != 1);

        }


    private static void findAndReserveRoom() throws ParseException {

        System.out.println("TO Reserve room first you need to create account with us Please enter option 3");
        displayMainMenu();
        System.out.println("Check if your account is exist with us or not");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your mail");


        final String customerEmail = sc.nextLine();

               if(customers.get(customerEmail)!=null) {
                   System.out.print("Account is existing");

                   System.out.println("\nEnter the room number to reserve");
                   String roomNum =sc.nextLine();
                   System.out.println("Enter the check in date");
                   Date checkIn,checkOut=null;
                   checkIn = new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(sc.nextLine());

                   System.out.println("Enter the check in date");
                   checkOut = new SimpleDateFormat(DEFAULT_DATE_FORMAT).parse(sc.nextLine());

                   reserveRoom(customerEmail,checkIn,checkOut,roomNum);

               }
               else {
                   System.out.println("Account is not existing please create new account");
                   displayMainMenu();
               }
            }




    private static void reserveRoom(final String customerEmail, final Date checkInDate,
                                    final Date checkOutDate, final String rooms) {
       hotelResource.bookARoom(customerEmail,rooms,checkInDate,checkOutDate);
    }

    private static void seeMyReservation() {

        final Scanner scanner = new Scanner(System.in);

        System.out.println("Enter you Email");
        final String customerEmail = scanner.nextLine();
        LinkedList<Reservation>allReservation = hotelResource.getCustomersReservations(customerEmail);

        System.out.println(allReservation);

    }



        public static void createCustomerAccount() {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please enter the email id");
            String CustomerEmail = scanner.nextLine();
            System.out.println("Please enter your first name");
            String CustomerFirstName = scanner.nextLine();
            System.out.println("Please enter your second name");
            String CustomerLastName = scanner.nextLine();
            Customer customer=new Customer(CustomerEmail,CustomerFirstName, CustomerLastName);
            hotelResource.createACustomer(CustomerEmail,customer);
            System.out.println("Account Successfully created Welcome!");
        }


    public static void displayMainMenu()
    {
        System.out.print("\nWelcome to the Hotel Reservation Application\n" +
                "--------------------------------------------\n" +
                "1. Find and reserve a room\n" +
                "2. See my reservations\n" +
                "3. Create an Account\n" +
                "4. Admin\n" +
                "5. Exit\n" +
                "--------------------------------------------\n" +
                "Select correct option :\n");
    }
}
