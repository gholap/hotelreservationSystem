package model;

import java.util.Objects;

public class Room implements IRoom{



    String roomNumber;
    Double Price;
    RoomType Enumeration;
    public Room(String roomNumber, Double price, RoomType enumeration) {
        this.roomNumber = roomNumber;
        Price = price;
        Enumeration = enumeration;
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber='" + roomNumber + '\'' +
                ", Price=" + Price +
                ", Enumeration=" + Enumeration +
                '}';
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setPrice(Double price) {
        Price = price;
    }

    public void setEnumeration(RoomType enumeration) {
        Enumeration = enumeration;
    }
    @Override
    public String getRoomNumber() {
        return roomNumber;
    }

    @Override
    public Double getRoomPrice() {
        return Price;
    }

    @Override
    public RoomType getRoomType() {
        return Enumeration;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Room room = (Room) o;
        return Objects.equals(roomNumber, room.roomNumber) && Objects.equals(Price, room.Price) && Enumeration == room.Enumeration;
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomNumber, Price, Enumeration);
    }
}
