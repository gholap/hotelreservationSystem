package model;

import Service.CustomerService;

public class Tester {

    public static void main(String args[])
    {

        //Customer customer=new Customer("Gholam","Umesh","gholapumesh10@gmail.com");
        //System.out.println(customer);

        //CustomerService.addCustomer("gholapumesh10@gmail.com","umesh","gholap");

       // System.out.println(CustomerService.getCustomer("gholapumesh10@gmail.com"));

        Room rm=new Room("1",200.00,RoomType.SINGLE);
        System.out.println(rm.getRoomNumber());

    }

}
