package model;

public enum RoomType

{
    SINGLE("1"),
    DOUBLE("2");
    public final String label;

     RoomType(String label) {
        this.label = label;
    }

    public static RoomType valueOfLabel(String label) {
        for (RoomType typeOfRoom : values()) {
            if (typeOfRoom.label.equals(label)) {
                return typeOfRoom;
            }
        }
        throw new IllegalArgumentException();
    }
}
