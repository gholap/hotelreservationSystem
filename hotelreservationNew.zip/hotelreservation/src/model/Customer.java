package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Customer {


    String firstName;
    String lastName;
    String Email;
    @Override
    public String toString() {
        return "Customer{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", Email='" + Email + '\'' +
                '}';
    }


    public Customer(String firstName, String lastName, String email) {

        this.firstName = firstName;
        this.lastName = lastName;
        if(!ValidateEmail(email)) {
            this.Email = email;
        }
        else{
            throw new IllegalArgumentException("Invalid Email");
        }
    }


    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {


        return Email;
    }


    boolean ValidateEmail(String Email) {
        String re = "^(.+)@(.+).(.+)$";
        Pattern pattern = Pattern.compile(re);
        Matcher matcher = pattern.matcher(Email);
        return matcher.matches();

    }


}
