package Service;


import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;


/**
 * @author Umesh Gholap
 *
 */
public class ReservationService {

    private static final ReservationService SINGLETON = new ReservationService();
    private static final int ROOMS_DEFAULT_DAYS = 7;

    public static HashMap<String, IRoom> rooms = new HashMap<>();

    public static LinkedList<IRoom> roomNum = new LinkedList<>();
    HashMap<String, LinkedList<Reservation>> reservations = new HashMap<>();
    private ReservationService() {
    }

    public static ReservationService getSingleton() {
        return SINGLETON;
    }

    public void addRoom(IRoom room) {

        rooms.put(room.getRoomNumber(), room);
        roomNum.add(room);
    }
    public IRoom getARoom(String roomNumber) {
        return rooms.get(roomNumber);
    }

    public LinkedList<IRoom> getAllRooms() {
        return roomNum;
    }

    public Reservation reserveRoom(Customer customer, IRoom room,
                                   Date checkInDate, Date checkOutDate) {

        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        LinkedList<Reservation> customerRes = getCustomersReservation(customer);

        if (customerRes == null) {
            customerRes = new LinkedList<>();
        }

        customerRes.add(reservation);
        reservations.put(customer.getEmail(), customerRes);

        return reservation;
    }
    public LinkedList<Reservation> getCustomersReservation(Customer customer) {
        return reservations.get(customer.getEmail());
    }

    public void displayAllReservation() {
        final Collection<Reservation> res = getAllReservations();

        if (res.isEmpty()) {
            System.out.println("Reservations not found");
        } else {
            for (Reservation reservationVal : res) {
                System.out.println(reservationVal + "\n");
            }
        }
    }

    private Collection<Reservation> getAllReservations() {
        LinkedList<Reservation> Reservations = new LinkedList<>();

        for(LinkedList<Reservation> resVal : reservations.values()) {
            Reservations.addAll(resVal);
        }

        return Reservations;
    }

    public Collection<IRoom> findRooms(final Date checkInDate, final Date checkOutDate) {
        return findAvailableRooms(checkInDate, checkOutDate);
    }

    public Collection<IRoom> findAlternateRooms(final Date checkInDate, final Date checkOutDate) {
        return findAvailableRooms(DefaultDays(checkInDate), DefaultDays(checkOutDate));
    }

   /*     private Collection<IRoom> findAvailableRooms(final Date checkInDate, final Date checkOutDate) {
            final Collection<Reservation> allRes = getAllReservations();
            //System.out.println("Get all the reservation");
            final LinkedList<IRoom> roomsNotAvailable = new LinkedList<>();

           // System.out.println("Create collection where rooms not available");
            for (Reservation res : allRes) {
                if (checkInDate.before(res.getCheckOutDate())
                        && checkOutDate.after(res.getCheckInDate())) {
                    roomsNotAvailable.add(res.getRoom());
                }
            }

          LinkedList<IRoom> roomNum =getAllRooms();
            LinkedList<IRoom> available = new LinkedList<>();

            //comparison output in linked list
            try {
                   if(!roomsNotAvailable.isEmpty()) {
                       for (int i = 0; i <= roomNum.size(); i++) {


                           if (roomsNotAvailable.get(i) != roomNum.get(i)) {
                               available.add(roomNum.get(i));
                           }
                       }
                   }
            }catch (IndexOutOfBoundsException e)
            {
                //System.out.println(e);
            }



            return available;


    }


    public Date DefaultDays(final aaaDate date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, ROOMS_DEFAULT_DAYS);

        return calendar.getTime();
    }
    */

    private Collection<IRoom> findAvailableRooms(final Date checkInDate, final Date checkOutDate) {

        final Collection<Reservation> allRes = getAllReservations();
         LinkedList<IRoom> rooms= getAllRooms() ;

        LinkedList<IRoom> available= new LinkedList<>();

        LinkedList<IRoom> notAvailable= new LinkedList<>();


         for(IRoom room:rooms)
         {
            for(Reservation res:allRes)
            {
                if(res.getRoom().getRoomNumber()==room.getRoomNumber())
                {
                    notAvailable.add(room);
                }
                else
                {
                    available.add(room);

                }
            }
         }

         //System.out.println("Do you want to show recommended rooms")


        return available;
    }

    public Date DefaultDays(final Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, ROOMS_DEFAULT_DAYS);

        return calendar.getTime();
    }
}

