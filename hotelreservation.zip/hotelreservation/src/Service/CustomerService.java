package Service;


import model.Customer;
import java.util.HashMap;
import java.util.Map;


/**
 * @author Umesh Gholap
 *
 */
public class CustomerService {

    private static final CustomerService SINGLETON = new CustomerService();

    public static  HashMap<String, Customer> customers = new HashMap<>();

    private CustomerService() {}

    public static CustomerService getSingleton() {
        return SINGLETON;
    }

    public void addCustomer( String email,Customer customer) {
        customers.put(email, customer);
    }

    public Customer getCustomer(String customerEmail) {
        return customers.get(customerEmail);
    }

    public Map<String, Customer> getAllCustomers() {

        return customers;
    }


}
