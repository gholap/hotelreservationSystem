package api;


import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

/**
 * @author Umesh Gholap
 *
 */
public class HotelResource {

    private static final HotelResource SINGLETON = new HotelResource();

    private final CustomerService customerService = CustomerService.getSingleton();
    private final ReservationService reservationService = ReservationService.getSingleton();

    private HotelResource() {}

    public static HotelResource getSingleton() {
        return SINGLETON;
    }

    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    public void createACustomer(String CustomerEmail,Customer customer) {
        customerService.addCustomer(customer.getEmail(),customer);
    }

    public IRoom getRoom(String roomNumber) {
        return reservationService.getARoom(roomNumber);
    }

    public Reservation bookARoom(String customerEmail,String room, Date checkInDate, Date checkOutDate) {
        return reservationService.reserveRoom(getCustomer(customerEmail), getRoom(room), checkInDate, checkOutDate);
    }

    public LinkedList<Reservation> getCustomersReservations(String customerEmail) {
         Customer customer = getCustomer(customerEmail);

        if (customer == null) {
            return null;
        }

        return reservationService.getCustomersReservation(getCustomer(customerEmail));
    }

    public Collection<IRoom> findARoom(final Date checkIn, final Date checkOut) {
        return reservationService.findRooms(checkIn, checkOut);
    }

    public Collection<IRoom> findAlternativeRooms(final Date checkIn, final Date checkOut) {
        return reservationService.findAlternateRooms(checkIn, checkOut);
    }

    public Date addDefaultPlusDays(final Date date) {
        return reservationService.DefaultDays(date);
    }









}
