package model;

import Service.CustomerService;
import Service.ReservationService;
import api.AdminResource;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

/**
 * @author Umesh Gholap
 *
 */
public class AdminMenu {

    private static final AdminResource adminResource = AdminResource.getSingleton();

    public static void adminMenu() {
        String option = "";
        final Scanner scanner = new Scanner(System.in);

        DisplayAdminMenu();

        try {
            do {
                option = scanner.nextLine();

                if (option.length() == 1) {
                    switch (option.charAt(0)) {
                        case '1':
                            displayAllCustomers();
                            break;
                        case '2':
                            displayAllRooms();
                            break;
                        case '3':
                            displayAllReservations();
                            break;
                        case '4':
                            addRoom();
                            break;
                        case '5':
                            MainMenu.displayMainMenu                                ();
                            break;
                        default:
                            System.out.println("Unknown action\n");
                            break;
                    }
                } else {
                    System.out.println("Error: Invalid action\n");
                }
            } while (option.charAt(0) != '5' || option.length() != 1);
        } catch (StringIndexOutOfBoundsException ex) {
            System.out.println("Received empty Input Existing the program");
        }
    }

    private static void DisplayAdminMenu() {
        System.out.print("\nAdmin Menu\n" +
                "--------------------------------------------\n" +
                "1. See all Customers\n" +
                "2. See all Rooms\n" +
                "3. See all Reservations\n" +
                "4. Add a Room\n" +
                "5. Go to Main Menu\n" +
                "--------------------------------------------\n" +
                "PLease select Right Option from the Menu:\n");
    }

    private static void addRoom() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("please Enter room number to reserve");
        String roomNumber = scanner.nextLine();
        System.out.println("Enter price of room");
        double roomPrice = scanner.nextDouble();
        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        RoomType roomType=null;
        try{
            roomType = RoomType.valueOfLabel(scanner.next());
        }catch (Exception e)
        {
            System.out.println("error");
        }

        Room room = new Room(roomNumber, roomPrice, roomType);

        adminResource.addRoom(room);
        System.out.println("room added successfully  great");


    }


    private static void displayAllRooms() {
        if (ReservationService.rooms.isEmpty()) {
            System.out.println("rooms not found");
        } else
        {
            System.out.println(ReservationService.rooms);
        }

    }

    private static void displayAllCustomers()
    {

        if (CustomerService.customers.isEmpty()) {
            System.out.println("No customers found.");
        } else
        {
            System.out.println(CustomerService.customers);
        }
        }


    private static void displayAllReservations()
    {
        adminResource.displayAllReservations();
    }
}
